#declare a variable calculate with operational values
puts "enter first number:"
	mul1 = gets.chomp
puts "enter second number:"
	mul2 = gets.chomp
	calculate_mul = ( mul1 * mul2 )
p calculate_mul
puts "enter first number:"
	sum1 = gets.chomp
puts "enter second number:"
	sum2 = gets.chomp
	calculate_sum =  ( sum1 + sum2 )
p calculate_sum
puts "enter first number:"
	sub1 = gets.chomp
puts "enter second number:"
	sub2 = gets.chomp
    calculate_sub = ( sub1 - sub2 )
p calculate_sub
puts "enter first number:"
	div1 = gets.chomp
puts "enter second number:"
	div2 = gets.chomp
	calculate_div = (div1 / div2)	
p calculate_div